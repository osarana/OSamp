CursorMultiply by skinme!
-------------------------

CursorMultiply will create all the cursors needed for Winamp2 skins from base cursors created by you.

You will need to create 9 cursors:

normal.cur	:	cursor when not over any buttons/sliders
close.cur	:	cursor when over close button
eqslid.cur	:	cursor when over vertical sliders
			(recommended: pointer with 2 vertical pronged
			arrow)
mainmenu.cur	:	cursor when over mainmenu button (top left
			main window)
titlebar.cur	:	cursor when over titlebar to move it
			(recommended: pointer with four pronged arrow)
posbar.cur	:	cursor when over horizontal sliders
			(recommended: pointer with 2 horizontal pronged
			arrow)
min.cur		:	cursor when over minimise button
psize.cur	:	cursor when resizing pl vertical down and
			horizontally east (recommended: pointer with 2
			pronged arrow: down and east)

NB: psize is not used as a base cursor but is unique and cannot be taken from any other cursor.

RUNNING CURMULTI.BAT
--------------------

Make sure the directory in which curmulti.bat is situated contains the above base cursors (made by you). If the directory contains cursors which CursorMultiply will attempt to create, you will be asked whether to overwrite these cursors. If you are at all unsure, press 'n' to exit the program and view the cursor in question in your cursor-creation program.

1. From a DOS-PROMPT: type

	CURMULTI

   From Windows: double-click CURMULTI.BAT

2. The program will check all base cursors are present. If any are missing, the program will tell you to check the cursors and will terminate.

3. Follow on-screen instructions.

4. On completion, program will terminate. You will either be taken back to the MS-DOS Prompt or left with the DOS window open, depending on how you initiated the program. If you are left with a window, click the close button (x) in the top right.

COMMENTS?
---------

You can email me at bruce@skinme.cjb.net with any queries regarding CursorMultiply. If you have any trouble creating the cursors or want to know how, visit the Winamp2 Skins forum:

	http://forums.winamp.com/forumdisplay.php?forumid=5


DISTRIBUTION
------------

If you want to distribute this archive, do so free-of-charge and do not  modify or change the archive in any way. It must contain:

		CURMULTI.BAT
		README.TXT
		INPUT.COM
		INPUT.TXT	(all unaltered)

COPYRIGHT
---------

CURMULTI.BAT & README.TXT Copyright skinme! 2002

INPUT.COM & INPUT.TXT Copyright William C. Parke 1986
                                for CHUG
                                Capitol Heath Users' Group
